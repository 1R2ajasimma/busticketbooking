package Bus;

import java.sql.*;
import java.util.Scanner;

public class BusT2 {

    static String url = "jdbc:mysql://localhost:3306/final";
    static String username = "root";
    static String password = "raja@123";

    public static void main(String[] args) {

        try (Connection con = DriverManager.getConnection(url, username, password);
             Scanner sc = new Scanner(System.in)) {

            while (true) {
                System.out.println("\n===== BUS TICKET BOOKING =====");
                System.out.println("1. View Available Seats");
                System.out.println("2. Book a Seat");
                System.out.println("3. View Booked Seats");
                System.out.println("4. Exit");
                System.out.println("5. Cancel Booking");

                System.out.print("Enter your choice: ");
                
                int choice = sc.nextInt();
                sc.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        // View available seats (where passenger_name is NULL)
                    
                        // View available seats (where passenger_name is NULL)
                        String queryAvailable = "SELECT seat_no FROM bus_booking WHERE passenger_name IS NULL";
                        try (Statement st = con.createStatement();
                             ResultSet rs = st.executeQuery(queryAvailable)) {

                            System.out.println("\n=== Available Seats ===");
                            int count = 0;
                            while (rs.next()) {
                                System.out.println("Seat " + rs.getInt("seat_no"));
                                count++;
                            }

                            if (count == 0) {
                                System.out.println("No available seats.");
                            } else {
                                System.out.println("Total Available Seats: " + count);
                            }

                        }
                        break;


                    case 2:
                        // Book seat
                        System.out.print("Enter seat number to book (1-10): ");
                        int seatNo = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter passenger name: ");
                        String name = sc.nextLine();

                        String checkQuery = "SELECT passenger_name FROM bus_booking WHERE seat_no = ?";
                        try (PreparedStatement ps = con.prepareStatement(checkQuery)) {
                            ps.setInt(1, seatNo);
                            ResultSet rs = ps.executeQuery();

                            if (rs.next()) {
                                if (rs.getString("passenger_name") == null) {
                                    // Seat is available, book it
                                    String bookQuery = "UPDATE bus_booking SET passenger_name = ? WHERE seat_no = ?";
                                    try (PreparedStatement bookPs = con.prepareStatement(bookQuery)) {
                                        bookPs.setString(1, name);
                                        bookPs.setInt(2, seatNo);
                                        bookPs.executeUpdate();
                                        System.out.println("Seat " + seatNo + " booked successfully for " + name);
                                    }
                                } else {
                                    System.out.println("Seat " + seatNo + " is already booked.");
                                }
                            } else {
                                System.out.println("Invalid seat number.");
                            }
                        }
                        break;

                    case 3:
                        // View booked seats
                        String queryBooked = "SELECT seat_no, passenger_name FROM bus_booking WHERE passenger_name IS NOT NULL ORDER BY seat_no";
                        try (Statement st = con.createStatement();
                             ResultSet rs = st.executeQuery(queryBooked)) {

                            System.out.println("\n=== Booked Seats ===");
                            System.out.printf("%-10s %-20s\n", "Seat No", "Passenger Name");
                            System.out.println("--------------------------------");

                            boolean found = false;
                            while (rs.next()) {
                                found = true;
                                System.out.printf("%-10d %-20s\n", rs.getInt("seat_no"), rs.getString("passenger_name"));
                            }

                            if (!found) {
                                System.out.println("No seats booked yet.");
                            }
                        }
                        break;

                    case 4:
                        System.out.println("Exiting... Thank you!");
                        return;
                        
                    case 5:
                        System.out.print("Enter seat number to cancel: ");
                        int cancelNo = sc.nextInt();
                        sc.nextLine();
                        String cancelQuery = "UPDATE bus_booking SET passenger_name = NULL WHERE seat_no = ?";
                        try (PreparedStatement cancelPs = con.prepareStatement(cancelQuery)) {
                            cancelPs.setInt(1, cancelNo);
                            int rows = cancelPs.executeUpdate();
                            if (rows > 0) {
                                System.out.println("Booking for seat " + cancelNo + " cancelled.");
                            } else {
                                System.out.println("Invalid seat number or seat already empty.");
                            }
                        }
                        break;


                    default:
                        System.out.println("Invalid choice.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}